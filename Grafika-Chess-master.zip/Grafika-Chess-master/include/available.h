#ifndef AVAILABLE_H
#define AVAILABLE_H

#define TRUE 1
#define FALSE 0

#include "scene.h"

    void showPAWNAvailables(Scene* scene);

    void showROOKAvailables(Scene* scene);

    void showKNIGHTAvailables(Scene* scene);

    void showBISHOPAvailables(Scene* scene);

    void showQUEENAvailables(Scene* scene);
    
    void showKINGAvailables(Scene* scene);
    

#endif