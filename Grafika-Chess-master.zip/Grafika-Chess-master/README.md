Grafika-Chess
